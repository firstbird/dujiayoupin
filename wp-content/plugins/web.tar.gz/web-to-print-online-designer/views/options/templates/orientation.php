<?php if (!defined('ABSPATH')) exit; ?>
<script type="text/ng-template" id="nbd.orientation">
</script>