export const headers = {
    'X-WP-Nonce': nbdl.nonce
}