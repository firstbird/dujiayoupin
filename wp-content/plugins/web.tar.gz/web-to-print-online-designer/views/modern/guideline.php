<div class="nbd-guideline-notation" aria-hidden="false" style="">
    <p><span class="notation-guiline" style="border-top-color: red;"></span><?php esc_html_e('Bleed', 'web-to-print-online-designer'); ?><br></p>
    <p><span class="notation-guiline" style="border-top-color: blue;"></span><?php esc_html_e('Trim Line', 'web-to-print-online-designer'); ?><br></p>
    <p><span class="notation-guiline" style="border-top-color: green; border-top-style: dashed;"></span><?php esc_html_e('Safe Zone', 'web-to-print-online-designer'); ?></p>
</div>