<div class="nbd-drop-upload-zone" id="nbd-drop-upload-zone" nbd-drop-zone="uploadFile(files)">
    <div class="nbd-drop-upload-zone-inner">
        <h2><?php esc_html_e('Drop file to upload', 'web-to-print-online-designer'); ?></h2>
    </div>
</div>