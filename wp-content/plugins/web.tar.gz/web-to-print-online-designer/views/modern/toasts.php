<div class="nbd-toasts">
    <div class="toast animate300 animated">
        <span><?php esc_html_e('All changes saved','web-to-print-online-designer'); ?></span>
        <i class="nbd-icon icon-nbd-clear nbd-close-toast"></i>
    </div>
</div>