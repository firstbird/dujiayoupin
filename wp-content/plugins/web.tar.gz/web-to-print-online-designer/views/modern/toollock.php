<div class="nbd-tool-lock" ng-show="settings.task == 'create'">
    <div class="main-tool-lock">
        <ul class="items-lock">
            <li class="item-lock nbd-tooltip-hover-left" title="Lock all adjustment"><i class="icon-nbd icon-nbd-lock"></i></li>
            <li class="item-lock nbd-tooltip-hover-left" title="Lock horizontal movement"><i class="icon-nbd icon-nbd-arrows-h"></i></li>
            <li class="item-lock active nbd-tooltip-hover-left" title="Lock vertical movement"><i class="icon-nbd icon-nbd-arrows-v"></i></li>
            <li class="item-lock nbd-tooltip-hover-left" title="Lock horizontal scaling"><i class="icon-nbd icon-nbd-expand horizontal horizontal-x"><sub>x</sub></i></li>
            <li class="item-lock nbd-tooltip-hover-left" title="Lock vertical scaling"><i class="icon-nbd icon-nbd-expand horizontal horizontal-y"><sub>y</sub></i></li>
            <li class="item-lock nbd-tooltip-hover-left" title="Lock rotation"><i class="icon-nbd icon-nbd-refresh rotate180"></i></li>
        </ul>
    </div>
</div>