<div class="tab-product tab <?php if( $active_product ) echo 'active'; ?>" id="tab-product">
    <div class="tab-main tab-scroll">
        <div class="nbd-products" >
            <div class="loaded">
                <svg class="circular" viewBox="25 25 50 50" >
                    <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
                </svg>
            </div>
            <div class="nbd-product nbd-product-tab">
                <div class="nbd-main-product">
                    <div id="nbo-options-wrap"></div>
                </div>
            </div>
        </div>
    </div>
</div>