<?php if ( ! defined( 'ABSPATH' ) ) { exit;} ?>
<p style='width: 50%;float: left;padding: 30px;border: 3px double #ddd;margin-top: 50px;top: 50%;'>We have detected that you are using Internet Explorer which isn't compatible with design editor. Please use one of the modern web browsers: Chrome, Firefox, Microsoft Edge, Safari...</p>
<img style='margin-left: 15px; float: left;' src='<?php echo NBDESIGNER_ASSETS_URL."images/robot.png"; ?>' />
