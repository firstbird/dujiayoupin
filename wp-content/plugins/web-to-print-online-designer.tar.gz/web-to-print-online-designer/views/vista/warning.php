<div class="nbd-warning">
<!--    <div class="item main-warning nbd-show">-->
<!--        <i class="nbd-icon-vista nbd-icon-vista-warning warning"></i>-->
<!--        <span class="title-warning">Warning Trouble</span>-->
<!--        <i class="nbd-icon-vista nbd-icon-vista-clear close-warning"></i>-->
<!--    </div>-->
<!---->
</div>