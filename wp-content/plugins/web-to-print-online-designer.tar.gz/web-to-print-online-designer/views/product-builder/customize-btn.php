<a class="button nbd-button" id="nbdpb-start-design"><?php _e('Customize', 'web-to-print-online-designer'); ?></a>
<div class="nbdpb-custom-design"></div>