<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly  ?>
<!--
           .o88             .o88											
           "888             "888										
ooo. .oo.   888oooo.    .oooo888   .ooooo.    .gggggo. ooooo   .ooooo.   ooo. .oo.    .ooooo.  oooo d8b
"888P"Y88b  d88' `88b  d88' `88b  d8Y  `88b  d8Y"       888   d88' `88b  "888P"Y88b  d8Y  `88b "888""8P
 888   888  888   888  888   888  888ooo88"  `88888Pb`  888   888   888   888   888  888ooo88"  888
 888   888  888.  888  888.  888  888.   .o  .    '888  888   888   888   888   888  888.   .o  888    .o.
o888o o888o 88`bod8P'  `Vtoan888o `V8boooY   `Vbood8V' o888o  `Vbood888  o888o o888o `V8boooY  d888b   Y8P
                                                               .    888
                                                               Ybood8V'

    It took quite some time to write that code... it would be amazing, if you don't steal it!
    Thank you!
    ~ Netbase ❤ Team ~
-->