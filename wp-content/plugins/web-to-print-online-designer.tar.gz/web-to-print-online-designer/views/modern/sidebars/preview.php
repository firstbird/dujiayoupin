<div class="nbd-sidebar-preview product-more-info">
    <div class="preview-head">
        <span><?php _e('infomation','web-to-print-online-designer'); ?></span>
        <i class="icon-nbd icon-nbd-fomat-highlight-off close-preview"></i>
    </div>
    <div class="main-preview tab-scroll">
        <div class="preview-body">
<!--            <div class="main-body">
                <img src="" alt="">
                <span class="product-name"></span>
                <span class="product-desc">Business cards are cards bearing business information about a company or individual. They are shared during formal introductions as a convenience and a memory aid. A business card typically includes the giver's name, company or business affiliation (usually with a logo) and contact information such as street addresses, telephone number(s), fax number, e-mail addresses and website. Before the advent of electronic communication business cards might also include telex details</span>
            </div>-->
        </div>
        <div class="preview-footer">
            <div class="main-footer">
                <button class="nbd-button"><?php _e('Choose','web-to-print-online-designer'); ?></button>
            </div>
        </div>
    </div>
</div>