<div class="nbd-guideline-notation" aria-hidden="false" style="">
    <p><span class="notation-guiline" style="border-top-color: red;"></span> Bleed<br></p>
    <p><span class="notation-guiline" style="border-top-color: blue;"></span> Trim Line<br></p>
    <p><span class="notation-guiline" style="border-top-color: green; border-top-style: dashed;"></span> Safe Zone</p>
</div>