<div class="nbd-toasts">
    <div class="toast animate300 animated">
        <span><?php _e('All changes saved','web-to-print-online-designer'); ?></span>
        <i class="nbd-icon icon-nbd-clear nbd-close-toast"></i>
    </div>
</div>